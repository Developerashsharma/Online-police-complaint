 <footer class="site-footer">
     <div class="text-center">
         &copy; 2023-24 ASHISH VISH All rights reserved.
         <a href="#" class="go-top">
             <i class="fa fa-angle-up"></i>
         </a>
     </div>
 </footer>